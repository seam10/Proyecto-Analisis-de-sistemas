package com.corhuila.Juan_Valdez;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JuanValdezApplicationTests {

	@Test
	void contextLoads() {
	}

}
