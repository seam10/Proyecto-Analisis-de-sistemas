package com.corhuila.Juan_Valdez;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JuanValdezApplication {

	public static void main(String[] args) {
		SpringApplication.run(JuanValdezApplication.class, args);
	}

}
